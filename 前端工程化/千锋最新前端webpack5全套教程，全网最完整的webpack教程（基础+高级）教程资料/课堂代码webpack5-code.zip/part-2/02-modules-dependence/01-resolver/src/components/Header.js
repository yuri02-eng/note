function Header() {
  return '<h1>header</h1>'
}

export default Header