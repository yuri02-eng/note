export const add = (x, y) => {
  return x + y
}

export const minus = (x, y) => {
  return x - y
}