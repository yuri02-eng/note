const add = (x, y) => {
  return x + y
}

const minus = (x, y) => {
  return x - y
}

module.exports = {
  add, 
  minus
}