require(['./requirejs/add.js', './requirejs/minus.js'], function(add, minus) {
  console.log(add(4, 5))
})