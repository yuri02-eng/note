const math = require('./math.js')

console.log(math.add(4, 5))