// import { add, minus } from './math'
// console.log(add(5, 6))
// import 'lodash'
// console.log(100)

import './style.css'
import './m.global.js'