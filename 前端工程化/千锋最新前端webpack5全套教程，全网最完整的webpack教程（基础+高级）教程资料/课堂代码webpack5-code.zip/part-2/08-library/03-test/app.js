const webpackNumbers = require('03-webpack-numbers')
console.log(webpackNumbers.wordToNum('One'))