import _ from 'lodash'
console.log(0)
console.log(_)