const { add } = require('../dist/mylib')
console.log(add(5, 6))