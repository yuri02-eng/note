const webpackNumbers = require('../dist/webpack-numbers')
console.log(webpackNumbers.numToWord(3))