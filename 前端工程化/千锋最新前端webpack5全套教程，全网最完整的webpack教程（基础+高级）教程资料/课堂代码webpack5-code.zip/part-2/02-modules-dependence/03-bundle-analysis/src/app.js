const math = require('./math')
console.log(math.add(4, 5))