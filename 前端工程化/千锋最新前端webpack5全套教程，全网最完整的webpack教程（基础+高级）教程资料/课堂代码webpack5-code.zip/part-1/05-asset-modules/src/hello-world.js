function helloWorld() {
  console.log('Hello world!!!!')
}

export default helloWorld