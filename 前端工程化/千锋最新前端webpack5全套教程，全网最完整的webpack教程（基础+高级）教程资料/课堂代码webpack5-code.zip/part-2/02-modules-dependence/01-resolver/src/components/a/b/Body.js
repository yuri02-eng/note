const math = require('@/math.js')
function Body () {
  console.log(math.add(4, 5))
}
export default Body