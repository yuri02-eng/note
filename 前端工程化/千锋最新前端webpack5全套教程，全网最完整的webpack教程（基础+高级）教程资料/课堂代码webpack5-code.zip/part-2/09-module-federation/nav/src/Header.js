const Header = () => {
  const header = document.createElement('h1')
  header.textContent = '公共头部内容'
  return header
}

export default Header