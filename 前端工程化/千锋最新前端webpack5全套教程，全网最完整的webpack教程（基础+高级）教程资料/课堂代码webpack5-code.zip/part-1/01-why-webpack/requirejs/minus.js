const minus = (x, y) => {
  return x - y
}

define([], function() {
  return minus
})