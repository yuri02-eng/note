// import _ from 'lodash'
// console.log(_.join(['hello', 'webpack'], ' '))
// this.alert('hello webpack')

const { file, parse } = require('./globals')
console.log(file)
parse()