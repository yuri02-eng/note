import _ from 'lodash'

console.log(_.join(['Another', 'module', 'loaded!'], ' '))