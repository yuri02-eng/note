import _ from 'lodash'
import Header from './components/Header'
import Body from './components/a/b/Body'
const math = require('./math')

// console.log(math.add(5, 6))
console.log(math)
console.log(_.join(['hello', 'webpack'], ' '))
console.log(Header())
Body()