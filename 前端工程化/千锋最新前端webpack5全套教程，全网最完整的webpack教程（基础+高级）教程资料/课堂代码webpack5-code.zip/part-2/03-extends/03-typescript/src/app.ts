import _ from 'lodash'
const age: number = 18
console.log(age)
console.log(_.join([]))