import helloWorld from './hello-world'

helloWorld()