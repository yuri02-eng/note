;(function(){
  var myName = "千锋大前端"
})()

// console.log(myName)

var result = (function(){
  var myName = "千锋大前端"
  return myName
})()

console.log(result)