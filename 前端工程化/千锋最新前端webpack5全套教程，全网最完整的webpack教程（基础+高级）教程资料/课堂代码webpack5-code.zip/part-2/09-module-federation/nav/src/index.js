import Header from './Header'

const div = document.createElement('div')
div.appendChild(Header())
document.body.appendChild(div)