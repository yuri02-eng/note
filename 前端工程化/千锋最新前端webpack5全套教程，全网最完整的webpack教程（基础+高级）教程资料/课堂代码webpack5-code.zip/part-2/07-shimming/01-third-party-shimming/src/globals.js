const file = 'example.txt'

const helpers = {
  test: function() {
    console.log('test something')
  },

  parse: function() {
    console.log('parse something')
  }
}