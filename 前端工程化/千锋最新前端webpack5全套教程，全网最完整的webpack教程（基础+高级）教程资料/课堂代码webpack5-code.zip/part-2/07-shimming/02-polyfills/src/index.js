// import '@babel/polyfill'
console.log(Array.from([1, 2, 3], x => x + x))