import _ from 'jquery'
console.log(_)