const add = (x, y) => {
  return x + y
}

define([], function() {
  return add
})