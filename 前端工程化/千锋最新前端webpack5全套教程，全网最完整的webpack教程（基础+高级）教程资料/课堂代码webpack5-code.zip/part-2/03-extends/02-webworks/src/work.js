self.onmessage = (message) => {
  self.postMessage({
    answer: 1111
  })
}